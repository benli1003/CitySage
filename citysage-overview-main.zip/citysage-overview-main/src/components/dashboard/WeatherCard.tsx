import { Sun, Cloud, CloudRain, AlertTriangle } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

interface Alert {
  id: string;
  type: 'warning' | 'info' | 'error';
  message: string;
}

const mockAlerts: Alert[] = [
  {
    id: "1",
    type: "warning",
    message: "Strong winds expected this afternoon"
  }
];

export const WeatherCard = () => {
  return (
    <DashboardCard
      title="Current Weather"
      icon={<Sun className="w-5 h-5" />}
    >
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-warning/20 rounded-full flex items-center justify-center">
              <Sun className="w-8 h-8 text-warning" />
            </div>
            <div>
              <div className="text-4xl font-bold text-card-foreground">72°</div>
              <div className="text-sm text-muted-foreground">Sunny</div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
          <div>
            <div className="text-sm text-muted-foreground">High: 78°</div>
            <div className="text-sm text-muted-foreground">Low: 65°</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Wind 5 mph</div>
          </div>
        </div>
        
        {/* Weather Alerts Section */}
        {mockAlerts.length > 0 && (
          <div className="pt-4 border-t border-border">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-warning" />
              <span className="text-sm font-medium text-card-foreground">Weather Alerts</span>
            </div>
            <div className="space-y-2">
              {mockAlerts.map((alert) => (
                <div key={alert.id} className="flex items-start gap-3 p-2 bg-warning-muted rounded border border-warning/20">
                  <AlertTriangle className="w-4 h-4 text-warning mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-card-foreground">{alert.message}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </DashboardCard>
  );
};